package com.yc.bean;

public class DishesBean {
	private int cp_id;
	private String name;
	private Double price;
	private String lable;
	private String pic;
	private String style;
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public int getCp_id() {
		return cp_id;
	}
	public String getName() {
		return name;
	}
	public Double getPrice() {
		return price;
	}
	public String getLable() {
		return lable;
	}
	public String getPic() {
		return pic;
	}
	public void setCp_id(int cp_id) {
		this.cp_id = cp_id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public void setLable(String lable) {
		this.lable = lable;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
	public DishesBean(int cp_id, String name, Double price, String lable, String pic, String style) {
		super();
		this.cp_id = cp_id;
		this.name = name;
		this.price = price;
		this.lable = lable;
		this.pic = pic;
		this.style = style;
	}
	public DishesBean() {
		super();
	}
	
	
}
