package com.yc.util;

public class PageUtil {
	private int sizePerPage ;//每页多少条
	private int totalSize ;//总共多少条
	private int pageNo ;//页码=1 
	private int totalPages ;//总共多少页
	
	
	
	public int getSizePerPage() {
		return sizePerPage;
	}
	public void setSizePerPage(int sizePerPage) {
		if(sizePerPage<=0){
			this.sizePerPage =10;
		}else{
			this.sizePerPage = sizePerPage;
		}
		
	}
	public int getTotalSize() {
		return totalSize;
	}
	public void setTotalSize(int totalSize) {
		if(totalSize<=0){
			this.totalSize =0;
		}
		this.totalSize = totalSize;
	}
	public int getPageNo() {
		return pageNo;
	}
	public void setPageNo(int pageNo) {
		if(pageNo<=1){
			this.pageNo=1;
		}else{
			this.pageNo = pageNo;
		}
		
	}
	public int getTotalPages() {
		if(this.totalSize%this.sizePerPage==0){
			this.totalPages=this.totalSize/this.sizePerPage;
		}else{
			this.totalPages=this.totalSize/this.sizePerPage+1;
		}
		
		return totalPages;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	public int prePage (){
		int preNo=1;
		if(this.pageNo>1){
			preNo=this.pageNo-1;
		}else{
			preNo=1;
		}
		return preNo;
	} 
	
	public int nextPage (){
		int nextNo=1;
		//System.out.println("--------pageNO------"+getPageNo());
		//System.out.println("----pages-:"+this.getTotalPages());
		if(this.getPageNo()<this.getTotalPages()){
			nextNo =this.getPageNo()+1;
		}else{
			nextNo =this.getTotalPages();
		}
		//System.out.println("--------next:"+nextNo);
		return nextNo;
	}
	
	
	
}
