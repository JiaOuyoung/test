package recommend;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.yc.bean.DishesBean;
import com.yc.dao.DishesDao;
import com.yc.util.IDRandom;

public class DishisDaoTest {
	DishesDao dao = new DishesDao();

	@Test
	public void test() {
		System.out.println(IDRandom.getID("c"));
	}
	

	@Test
	
	public void find( ) throws Exception{
		DishesBean bean =new DishesBean();
		List<DishesBean> list = dao.findAllDishes(bean);
		System.out.println( list.get(0).getPrice());
		
		
	}

}
